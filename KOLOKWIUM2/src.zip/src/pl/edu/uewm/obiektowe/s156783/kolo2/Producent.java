package pl.edu.uewm.obiektowe.s156783.kolo2;

public enum Producent {
    FORD, AUDI, BMW, SKODA;
}
