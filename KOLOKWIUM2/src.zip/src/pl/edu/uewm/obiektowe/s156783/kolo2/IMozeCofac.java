package pl.edu.uewm.obiektowe.s156783.kolo2;

public interface IMozeCofac {
    default String cofaj(){
       return "Uwaga, cofam...";
    };
}
